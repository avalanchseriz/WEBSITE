// Smooth scrolling for navigation links
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        // Scroll smoothly to the target section
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Form Submission Handling
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();
    // For now, simply alert that the message is sent
    alert('Message Sent!');
});
